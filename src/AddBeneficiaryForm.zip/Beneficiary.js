import { useState, useEffect } from 'react';
import { Modal, Button } from 'react-bootstrap';
import EditBeneficiaryForm from './EditBeneficiaryForm'


const BeneficiaryTableData = ({ beneficiaryData }) => {

    const [show, setShow] = useState(false);

    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);

    useEffect(() => {
        handleClose()
    }, [beneficiaryData])

    return (
        <>
            <td>{beneficiaryData.name}</td>
            <td>{beneficiaryData.age}</td>
            <td>{beneficiaryData.address}</td>
            <td><button onClick={handleShow} className="btn text-warning btn-act" data-toggle="modal">Edit</button></td>

            <Modal show={show} onHide={handleClose}>

                <Modal.Header closeButton>
                    <Modal.Title>Edit Beneficiary</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <EditBeneficiaryForm beneficiaryData={beneficiaryData} />
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>Close</Button>
                </Modal.Footer>

            </Modal>
        </>
    )
}

export default BeneficiaryTableData;