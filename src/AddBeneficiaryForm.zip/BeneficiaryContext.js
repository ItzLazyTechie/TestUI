import { createContext, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

export const BeneficiaryContext = createContext()

const BeneficiaryContextProvider = (props) => {

    const [beneficiaries, setBeneficiaries] = useState([
        //initial data
        {
            id: uuidv4(),
            name: 'SYED',
            age: '25',
            address: 'USA'
        },
        {
            id: uuidv4(),
            name: 'JOHN',
            age: '33',
            address: 'INDIA'
        }
    ])

    useEffect(() => {
        setBeneficiaries(JSON.parse(localStorage.getItem('beneficiaries')))
    }, [])

    useEffect(() => {
        localStorage.setItem('beneficiaries', JSON.stringify(beneficiaries));
    })


    const addBeneficiaryData = (name, age, address) => {
        setBeneficiaries([...beneficiaries, { id: uuidv4(), name, age, address }])
    }


    const updateBeneficiaryData = (id, editedBeneficiaryData) => {
        setBeneficiaries(beneficiaries.map((beneficiary) => beneficiary.id === id ? editedBeneficiaryData : beneficiary))
    }

    return (
        <BeneficiaryContext.Provider value={{ beneficiaries, addBeneficiaryData, updateBeneficiaryData }}>
            {props.children}
        </BeneficiaryContext.Provider>
    )
}

export default BeneficiaryContextProvider;