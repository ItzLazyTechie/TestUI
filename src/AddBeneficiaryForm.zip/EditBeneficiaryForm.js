import { Form, Button } from "react-bootstrap"

import {BeneficiaryContext} from './BeneficiaryContext';
import {useContext, useState} from 'react';

const EditBeneficiaryForm = ({beneficiaryData}) =>{

    const id = beneficiaryData.id;

    const [name, setName] = useState(beneficiaryData.name);
    const [age, setAge] = useState(beneficiaryData.age);
    const [address, setAddress] = useState(beneficiaryData.address);


    const {updateBeneficiaryData} = useContext(BeneficiaryContext);

    const editedBeneficiaryData = {id, name, age, address}

    const handleSubmit = (e) => {
        e.preventDefault();
        updateBeneficiaryData(id, editedBeneficiaryData)
    }

     return (

        <Form onSubmit={handleSubmit}>
            <Form.Group>
                <Form.Control
                    type="text"
                    placeholder="Beneficiary Name *"
                    name="name"
                    value={name}
                    onChange={(e)=> setName(e.target.value)}
                    required
                />
            </Form.Group>
            <Form.Group>
                <Form.Control
                    type="text"
                    placeholder="Beneficiary Age *"
                    name="age"
                    value={age}
                    onChange={(e)=> setAge(e.target.value)}
                    required
                />
            </Form.Group>
            <Form.Group>
                <Form.Control
                    as="textarea"
                    placeholder="Beneficiary Address"
                    rows={3}
                    name="address"
                    value={address}
                    onChange={(e)=> setAddress(e.target.value)}
                />
            </Form.Group>
           
            <Button variant="success" type="submit" block>
                Edit Beneficiary
            </Button>
        </Form>

     )
}

export default EditBeneficiaryForm;