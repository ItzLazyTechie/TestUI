import { Form, Button } from "react-bootstrap"

import { BeneficiaryContext } from './BeneficiaryContext';
import { useContext, useState } from 'react';

const AddBeneficiaryForm = () => {

    const { addBeneficiaryData } = useContext(BeneficiaryContext);

    const [beneficiary, setBeneficiary] = useState({
        name: "", age: "", address: ""
    });

    const onInputChange = (e) => {
        setBeneficiary({ ...beneficiary, [e.target.name]: e.target.value })
    }

    const { name, age, address } = beneficiary;

    const handleFormSubmit = (e) => {
        e.preventDefault();
        console.log("name : " + name + " and age : " + age + "and address : " + address);
        addBeneficiaryData(name, age, address);
    }

    return (

        <Form onSubmit={handleFormSubmit}>
            <Form.Group>
                <Form.Control
                    type="text"
                    placeholder="Beneficiary Name *"
                    name="name"
                    value={name}
                    onChange={(e) => onInputChange(e)}
                    required
                />
            </Form.Group>
            <Form.Group>
                <Form.Control
                    type="text"
                    placeholder="Beneficiary Age *"
                    name="age"
                    value={age}
                    onChange={(e) => onInputChange(e)}
                    required
                />
            </Form.Group>
            <Form.Group>
                <Form.Control
                    as="textarea"
                    placeholder="Beneficiary Address"
                    rows={3}
                    name="address"
                    value={address}
                    onChange={(e) => onInputChange(e)}
                />
            </Form.Group>

            <Button variant="success" type="submit">
                Add New Beneficiary
            </Button>
        </Form>

    )
}

export default AddBeneficiaryForm;