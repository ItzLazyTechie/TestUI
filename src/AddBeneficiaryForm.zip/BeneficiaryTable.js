import { Modal, Button } from 'react-bootstrap';
import { useContext, useEffect, useState } from 'react';
import { BeneficiaryContext } from './BeneficiaryContext';
import Beneficiary from './Beneficiary';
import AddBeneficiaryForm from './AddBeneficiaryForm'; 

const BeneficiaryTable = () => {

    const { beneficiaries } = useContext(BeneficiaryContext);

    const [show, setShow] = useState(false);

    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);


    useEffect(() => {
        handleClose();
    }, [beneficiaries])


    return (
        <>

            <div className="table-title">
                <div className="row">
                    <div className="col-sm-6">
                        <Button onClick={handleShow} className="btn" data-toggle="modal">
                            Add Beneficiary
                        </Button>
                    </div>
                </div>
            </div>


            <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {
                        beneficiaries.map(beneficiaryData => (
                            <tr key={beneficiaryData.id}>
                                <Beneficiary beneficiaryData={beneficiaryData} />
                            </tr>
                        ))
                    }

                </tbody>
            </table>


            <Modal show={show} onHide={handleClose}>

                <Modal.Header closeButton>
                    <Modal.Title>Add Beneficiary</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    < AddBeneficiaryForm />
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>Close</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default BeneficiaryTable;